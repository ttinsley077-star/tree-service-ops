Tree Service Ops - Mobile Prototype

WHAT IT DOES
- Admin view: new customer/quote, status tracking, bid values, booked revenue, completed revenue, 15% commission.
- Field Manager view: confirm availability, submit bid, mark job complete.
- Data is stored locally in the browser for this prototype.

IMPORTANT
This prototype does NOT sync between two different phones yet.
A production version needs a shared cloud database and authentication.

HOW TO TRY IT
1. Unzip the folder.
2. Open index.html in a browser.
3. Use the role switch in the upper-right to change between Admin and Field Manager.
4. Add a lead and move it through the workflow.

Suggested production upgrade:
- Shared cloud database
- Separate admin/field-manager logins
- Text/push notifications
- Customer confirmation links
- Photo uploads
- Automatic 15% commission reporting
